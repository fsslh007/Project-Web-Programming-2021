<?php 
    include '../core/init.php';

    User::logout();
   
?>